export const environment = {
  production: true,
  // apiURL:"https://api-upwork-graduation-project.herokuapp.com"
  apiURL:"http://localhost:5000"
};
